msg_reply.sign = {
    keyword = {
        prefix = { "签订魔物" }
    },
    limit = {
        cd = 10
    },
    echo = { lua = "sign" }
}